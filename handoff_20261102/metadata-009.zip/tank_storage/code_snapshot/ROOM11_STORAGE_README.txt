ROOM 11 STORAGE COUNTER — EXPERIMENTAL VIDEO INTEGRATION

Requested event: cheese is placed at the two-worker production station and
the associated tank leaves room11. Emit one storage record with date and time.
No fullness, block quantity or weight is estimated for this output.

Run from the workspace root:
work/feta_env/Scripts/python.exe work/run_storage_video.py --video VIDEO.mp4 --date YYYY-MM-DD --out NEW_RUN_DIRECTORY

Models reused, not retrained:
 - tank detector pilot v2 (f4d36892d12d0a1d13fb2233ffcf47ce084857be076fadfff628b11da1e357ed)
 - carried-cheese detector v5 (5d7ef4062b15592d64d76a3b0866df648eb84d13f67e591a76d8d482efd76b07)

The payload trajectory must originate in the pickup corridor and end inside
the production tank polygon. The quantity classes are collapsed to presence.
A qualifying placement arms a single-use station episode. A tank trajectory
from that station to the exit consumes the episode, even when detector IDs
fragment during covering. A decoded-frame gap over0.5s resets the episode.
This is an experimental association, not a proven physical identity system.

Time is OCR'd from the visible DVR clock with agreement between two image
thresholds. Missing/disagreeing OCR is withheld in clock_audit.json. The source
date is explicitly supplied. Neither filename+PTS nor wall-clock runtime is
substituted for the camera time.

User output: clock_v2/storage_predictions.json (event, date, time only).
Audit: result.json, observations.jsonl, frozen_config.json, clock_audit.json,
exit overlays and original clock crops. Review output before operational use.

LIMITATIONS:
 - The payload release is inferred from disappearance after inward movement.
 - Station association and OCR are predictions, not human-certified events.
 - Native1920x1080 and this fixed camera geometry only.
 - No cross-file state or overlap reconciliation in this runner yet.
 - A tank already filled before recording can remain unqualified.
 - Positive development example10/10 is not held-out reliability evidence.
 - Frozen28/10 results and original videos remain unchanged.
