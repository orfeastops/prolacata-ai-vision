from pathlib import Path
import json
from datetime import datetime,timezone
b=Path('D:/Codex/tank-day28/heldout_counting');r=b/'day28_runs';now=datetime.now(timezone.utc).isoformat()
def rd(p):return json.loads(p.read_text())
def wr(p,q):p.write_text(json.dumps(q,indent=2))
clocks=['13:59:48 / 13:59:39','14:00:07 / 14:00:17','14:00:55 / 14:01:05','14:01:32 / 14:02:03','14:02:33 / 14:02:27','14:03:39 / 14:04:50','14:05:10 / 14:07:00','14:07:44 / 14:10:33'];n=0
for i in range(153,161):
 p=r/f'final_boundary_{i-1}_{i}'/'evidence.json';q=rd(p);n+=len(q['samples']);q.update(visual_review_pending=False,reviewed_at=now,visually_reviewed_samples=len(q['samples']),review_notes='Previous sampled tail / next first visible clocks: '+clocks[i-153]+'. People hosing floor/walls, stationary tank at left. No sampled tank departure. Gaps and repeated frames retained.',aggregation_allowed=False);wr(p,q)
 p=r/f'clip_{i:03}'/'review_queue.json';q=rd(p);q.update(review_status='sampled_visual_review_complete',reviewed_at=now);q['review_notes']=q['review_notes'].replace('Boundaries pending.','Adjacent boundary samples reviewed; recording gaps retained.');wr(p,q)
p=r/'manual_review_progress.json';q=rd(p);q.update(reviewed_clips=[f'clip_{i:03}' for i in list(range(62))+list(range(63,161))],reviewed_raw_samples=1826,reviewed_boundary_samples=876+n,partially_reviewed_clips=[],partial_reviewed_raw_samples=0,updated_at=now,note='All160 additional clips sampled; fullclip062 separate. Final boundaries139-160 inspected, sampler finished. Earlier overlap evidence consolidation remains per final_reconciliation_todo.json.22 block-loaded and1other-material unchanged; fullclip separately3; daily aggregation pending.');wr(p,q)
p=b/'review.html';h=p.read_text(encoding='utf-8');h=h.replace('152 πρόσθετα αποσπάσματα: 1793 αραιά, 936 πυκνά και 876 δείγματα ορίων',f"160 πρόσθετα αποσπάσματα: 1826 αραιά, 936 πυκνά και {q['reviewed_boundary_samples']} δείγματα ορίων");h=h.replace('Τα υπόλοιπα 8 έχουν 33 ήδη ελεγμένα αραιά δείγματα, αλλά εκκρεμούν τα όριά τους.','Ολοκληρώθηκε η δειγματοληπτική επισκόπηση όλων των πρόσθετων αποσπασμάτων. Εκκρεμεί η τελική αντιστοίχιση παλαιότερων επικαλύψεων.');p.write_text(h,encoding='utf-8');print(q['reviewed_boundary_samples'])
