from pathlib import Path
import hashlib,json
from datetime import datetime,timezone
b=Path('D:/Codex/tank-day28/heldout_counting');r=b/'day28_runs';rows=[];groups={}
for d in sorted(r.glob('clip_*')):
 p=d/'source.mp4'
 if not p.exists():continue
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 recorded=json.loads((d/'source.json').read_text()).get('sha256');rows.append(dict(clip=d.name,sha256=h,matches_recorded=h==recorded));groups.setdefault(h,[]).append(d.name)
q=dict(checked_at=datetime.now(timezone.utc).isoformat(),sources=len(rows),mismatches=[x for x in rows if not x['matches_recorded']],exact_duplicate_groups=[x for x in groups.values() if len(x)>1],files=rows,temporal_dedup_separate=True)
(r/'final_source_hash_audit.json').write_text(json.dumps(q,indent=2));print({k:v for k,v in q.items() if k!='files'})
