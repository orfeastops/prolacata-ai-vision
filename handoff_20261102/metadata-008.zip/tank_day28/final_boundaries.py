from pathlib import Path
import av,json,hashlib
from collections import deque
from PIL import Image,ImageDraw
b=Path('D:/Codex/tank-day28/heldout_counting/day28_runs')
for nxt in range(139,161):
 o=b/f'final_boundary_{nxt-1}_{nxt}';o.mkdir(exist_ok=True);rows=[];tiles=[];firsthash=None;matches=[]
 for idx in [nxt,nxt-1]:
  frames=deque(maxlen=4);target=0
  with av.open(str(b/f'clip_{idx:03}'/'source.mp4')) as c:
   s=c.streams.video[0];s.codec_context.thread_count=1;origin=float(s.start_time*s.time_base) if s.start_time is not None else 0
   for f in c.decode(video=0):
    if f.time is None:continue
    t=float(f.time)-origin
    if idx==nxt and t>8:break
    digest=hashlib.sha256(b''.join(bytes(p) for p in f.planes)).hexdigest()
    if idx==nxt and firsthash is None:firsthash=digest
    if idx!=nxt and digest==firsthash:matches.append(t)
    if t<target:continue
    target=t+3.99;frames.append((t,f.to_image()))
  for t,im in frames:
   name=f'clip{idx}_{len(rows):03}.jpg';im.save(o/name,quality=88);tile=Image.new('RGB',(640,390));tile.paste(im.resize((640,360)),(0,30));ImageDraw.Draw(tile).text((5,5),f'clip{idx} PTS{t:.3f}',fill='white');tiles.append(tile);rows.append(dict(clip=idx,pts_s=t,file=name))
 sh=Image.new('RGB',(1920,1170))
 for j,tile in enumerate(tiles):sh.paste(tile,((j%3)*640,(j//3)*390))
 sh.save(o/'sheet_00.jpg');(o/'evidence.json').write_text(json.dumps(dict(samples=rows,exact_decoded_plane_first_frame_matches_in_previous=matches,visual_review_pending=True),indent=2));print(nxt,len(rows),matches,flush=True)
