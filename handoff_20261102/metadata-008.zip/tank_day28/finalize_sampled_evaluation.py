import json,re,html
from pathlib import Path
from datetime import datetime,timezone
b=Path('D:/Codex/tank-day28/heldout_counting');r=b/'day28_runs';now=datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8')
clocks={2:('06:44:23','06:44:14'),12:('07:07:39','07:07:36'),13:('07:07:52','07:07:46'),14:('07:08:14','07:08:11'),16:('07:12:04','07:11:57'),17:('07:12:58','07:12:54'),18:('07:13:26','07:13:32'),20:('07:15:14','07:15:08'),21:('07:16:16','07:16:12'),24:('07:17:54','07:17:50'),25:('07:18:11','07:18:03'),27:('07:19:24','07:19:20'),28:('07:19:41','07:19:36'),32:('07:23:55','07:23:51'),34:('07:25:43','07:25:28'),36:('07:28:51','07:28:47'),40:('07:53:34','07:53:30'),42:('07:55:41','07:55:36'),45:('08:07:57','08:08:02'),46:('08:08:51','08:08:57'),48:('08:10:25','08:10:10'),51:('08:41:50','08:41:56'),62:('09:44:07','09:44:00'),63:('10:04:57','10:04:55'),70:('10:22:20','10:22:15'),75:('10:29:02','10:29:08')}
for i,(a,z) in clocks.items():
 p=r/f'consolidated_boundary_{i-1}_{i}'/'evidence.json';d=read(p)
 d.update(visual_review_pending=False,reviewed_at=now,previous_last_sample_clock=a,next_first_sample_clock=z,observed_departure_in_samples=False,review_note='Previously reviewed raw frames re-inspected together. Stationary tanks and worker activity; no departure observed in these samples. Coarse clock comparison only, not frame-exact overlap duration. No new sample counter increment.')
 save(p,d)
q=read(b/'day28_camera11_queue.json');pairs=[]
for f in q['files']:
 i=f['index']
 if f['overlap_with_previous_union_s']>0:
  ps=[r/f'{prefix}_{i-1}_{i}'/'evidence.json' for prefix in ['consolidated_boundary','boundary','final_boundary']]
  p=next(p for p in ps if p.exists() and read(p).get('visual_review_pending') is False)
  pairs.append({'previous':i-1,'next':i,'evidence':str(p.relative_to(b)),'review':'sampled_visual_boundary_review_complete'})
assert len(pairs)==57
save(r/'final_overlap_reconciliation.json',{'updated_at':now,'pairs':pairs,'count':57,'scope':'Sampled boundary review and distinct reviewed event clock reconciliation; not an exhaustive proof of zero missed departures.'})
events=[]
for p in sorted(r.glob('clip_*/review_queue.json')):
 d=read(p)
 for e in d.get('event_reviews',[]):
  if e.get('decision')=='visually_confirmed_loaded_departure':
   assert e.get('overlay_reviewed') is True
   events.append({'clip':p.parent.name,**e,'review_record':str(p.relative_to(b))})
assert len(events)==22,len(events)
full=read(b/'test28_fullclip/evaluation_summary.json')
for e in full['events']:
 assert e['event_overlay_reviewed']
 events.append({'clip':'fullclip_062','visible_clock':e['camera_clock'],**e,'review_record':'test28_fullclip/evaluation_summary.json'})
assert len(set(e['visible_clock'] for e in events))==25
assert all((r/f'clip_{i:03d}'/'review_queue.json').exists() for i in range(161) if i!=62)
summary={'status':'completed_sampled_evaluation','updated_at':now,'camera':11,'date':'2026-10-28','reviewed_source_files':161,'additional_files':160,'confirmed_distinct_block_loaded_departures':25,'additional_clip_loaded_departures':22,'fullclip_loaded_departures':3,'other_material_departures':1,'daily_production_count':None,'reference_exhaustive':False,'automatic_fullness_classifier':False,'filename_overlap_flags_reviewed':57,'coverage_metadata':read(b/'day_coverage_metadata.json')[0],'events':sorted(events,key=lambda e:e['visible_clock']),'limits':['Sampled manual reference; missed events between samples remain possible.','Recording gaps; this is a confirmed count in available reviewed footage, not whole-day production.','Visible stacked white blocks linked to sampled pickup and exit; no fullness percentage or weight.','First three-minute test is included in fullclip062 and not added again.','No camera15 match; model and thresholds unchanged.'],'additional_sample_counters':{k:v for k,v in read(r/'manual_review_progress.json').items() if k in ['reviewed_raw_samples','reviewed_dense_samples','reviewed_boundary_samples']}}
save(b/'final_evaluation_summary.json',summary)
p=r/'manual_review_progress.json';d=read(p);d.update(aggregation_ready=True,confirmed_available_footage_loaded_count=25,daily_count=None,updated_at=now,note='Completed sampled evaluation and57 overlap flag reviews.25 distinct block-loaded departures including3 fullclip events;1 other material separate. Not exhaustive daily production.');save(p,d)
p=r/'final_reconciliation_todo.json';d=read(p);d.update(status='completed_sampled_reconciliation',earlier_filename_overlap_pairs_requiring_evidence_consolidation=[],completed_at=now,note='All26 consolidated sheets inspected;57 overlap flags linked to reviewed evidence. See final_overlap_reconciliation.json.');save(p,d)
rows=''.join('<tr><td>'+html.escape(e['visible_clock'])+'</td><td>'+html.escape(e['clip'])+'</td><td><a href="'+e['review_record'].replace('\\','/')+'">Αποδεικτικά ελέγχου</a></td></tr>' for e in summary['events'])
section='<section id="current-review-status"><h2>Τελικό αποτέλεσμα δειγματοληπτικής αξιολόγησης — 28/10/2026, camera11</h2><p><b>25 διακριτές έξοδοι δεξαμενών με ορατά στοιβαγμένα λευκά τεμάχια</b>:22 στα πρόσθετα αποσπάσματα και3 στο fullclip062. Μία έξοδος με διαφορετική μορφή περιεχομένου παραμένει χωριστά.</p><p>161 αρχεία με δειγματοληπτική οπτική επισκόπηση, πυκνότερο έλεγχο συμβάντων και overlays. Στα160 πρόσθετα αρχεία:1826 αραιά,936 πυκνά και930 δείγματα ορίων· οι κατηγορίες μπορεί να επικαλύπτονται και δεν αθροίζονται ως μοναδικά καρέ.57 σημαίες επικάλυψης αντιπαραβλήθηκαν με αποδεικτικά.160 πρόσθετες πηγές επαληθεύτηκαν με SHA256 χωρίς διαφορές ή ακριβή διπλότυπα.</p><p><b>Δεν είναι συνολική παραγωγή ημέρας.</b> Η αναφορά είναι δειγματοληπτική και υπάρχουν κενά καταγραφής. Τα ονόματα αρχείων υποδεικνύουν περίπου5,225 ώρες ένωσης διαστημάτων και78 κενά, όχι επαληθευμένη συνεχή κάλυψη. Δεν τεκμηριώνεται ποσοστό πληρότητας, βάρος, αυτόματη αναγνώριση περιεχομένου ή σύνδεση με camera15. Το προηγούμενο τρίλεπτο δεν προστίθεται ξανά.</p><p><a href="final_evaluation_summary.json">Τελική σύνοψη JSON</a> · <a href="day28_runs/final_overlap_reconciliation.json">57 έλεγχοι επικαλύψεων</a></p><table><tr><th>Ρολόι κάμερας</th><th>Απόσπασμα</th><th>Τεκμηρίωση</th></tr>'+rows+'</table></section>'
p=b/'review.html';s=p.read_text(encoding='utf-8');s,n=re.subn(r'<section id="current-review-status">.*?</section>',lambda m:section,s,count=1,flags=re.S);assert n==1;p.write_text(s,encoding='utf-8')
print(json.dumps({'count':25,'overlaps':57,'events':len(events),'report_updated':True}))
