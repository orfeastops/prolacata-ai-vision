from pathlib import Path
import json,hashlib
from datetime import datetime,timezone
b=Path('D:/Codex/tank-day28/heldout_counting');r=b/'day28_runs';now=datetime.now(timezone.utc).isoformat()
def rd(p):return json.loads(p.read_text())
def wr(p,q):p.write_text(json.dumps(q,indent=2))
clocks=['12:55:36 / 12:55:28','12:55:50 / 12:56:04','12:56:20 / 12:59:15','12:59:51 / 12:59:40','13:00:05 / 12:59:57','13:00:44 / 13:00:36','13:00:54 / 13:00:47','13:01:15 / 13:04:04','13:04:36 / 13:06:37','13:09:07 / 13:09:23','13:09:42 / 13:09:37','13:10:01 / 13:09:51','13:10:14 / 13:10:09','13:10:35 / 13:10:47','13:11:19 / 13:11:28','13:11:43 / 13:11:55','13:12:28 / 13:12:44','13:13:53 / 13:14:25']
bn=0
for i in range(121,141):
 p=r/f'boundary_{i-1}_{i}'/'evidence.json';q=rd(p);n=len(q['samples']);bn+=n
 q.update(reviewed_at=now,visually_reviewed_samples=n,visual_review_pending=i>=139,aggregation_allowed=False,review_notes=('Sampled previous tail / next first clocks: '+clocks[i-121]+'.' if i<139 else 'Next first samples inspected, but previous tail missing from sampler; supplemental tail required.')+' People/cleaning or stationary room; no sampled tank departure. Clock gaps and repeated first frames retained; sampling not exhaustive.')
 wr(p,q)
for i in range(121,139):
 p=r/f'clip_{i:03}'/'review_queue.json';q=rd(p);q.update(review_status='sampled_visual_review_complete',reviewed_at=now);q['review_notes']=q['review_notes'].replace('Boundaries pending.','Adjacent boundary samples reviewed; recording gaps retained.');wr(p,q)
for i in range(141,161):
 d=r/f'clip_{i:03}';q=rd(d/'review_queue.json');assert not q['automatic_proposals'];n=len(rd(d/'raw_review_10s'/'samples.json'))
 with (d/'source.mp4').open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 assert sha==rd(d/'source.json')['sha256']
 wr(d/'source_hash_review.json',dict(checked_at=now,sha256=sha,matches_recorded=True,exact_duplicates_in_recorded_sources=[p.parent.name for p in r.glob('clip_*/source.json') if p.parent!=d and rd(p).get('sha256')==sha]))
 q.update(review_status='sampled_raw_review_complete_boundary_pending',reviewed_at=now,reviewed_raw_samples=n,reviewed_dense_samples=0,sampling_s=10,manual_reference_exhaustive=False,confirmed_loaded_count=0,manual_observed_loaded_departures=0,aggregation_allowed=False,evidence=[str(x.relative_to(d)).replace('\\','/') for x in sorted((d/'raw_review_10s').glob('sheet_*.jpg'))],review_notes='All raw contact-sheet samples visually inspected: people hosing floor/walls, foam cleaning, stationary tank at left, door activity. No sampled tank departure. Boundaries pending. Sampling not exhaustive.');wr(d/'review_queue.json',q)
p=r/'manual_review_progress.json';q=rd(p);q.update(reviewed_clips=[f'clip_{i:03}' for i in list(range(62))+list(range(63,139))],reviewed_raw_samples=1658+sum(rd(r/f'clip_{i:03}'/'review_queue.json')['reviewed_raw_samples'] for i in range(121,139)),reviewed_boundary_samples=674+bn,partially_reviewed_clips=[f'clip_{i:03}' for i in range(139,161)],partial_reviewed_raw_samples=sum(rd(r/f'clip_{i:03}'/'review_queue.json')['reviewed_raw_samples'] for i in range(139,161)),updated_at=now,note='138 clips sampled through138 excluding062. All remaining raw samples through160 visually reviewed; boundaries139-160 pending (139/140 previous tails missing). No new sampled departures.22 block-loaded and1other-material unchanged; fullclip separately3. Daily aggregation pending.');wr(p,q)
p=b/'review.html';h=p.read_text(encoding='utf-8');h=h.replace('120 αποσπάσματα: 1658 αραιά δείγματα και 936 πυκνότερα δείγματα',f"138 αποσπάσματα: {q['reviewed_raw_samples']} αραιά δείγματα και 936 πυκνότερα δείγματα");h=h.replace('</body>',f"<p>Latest review {now}: 138 clips sampled; {q['reviewed_raw_samples']} coarse, 936 dense, {q['reviewed_boundary_samples']} boundary samples. Remaining 22 clips have {q['partial_reviewed_raw_samples']} coarse samples inspected, boundaries pending. No new observed departure. Daily aggregation pending; recording gaps retained.</p></body>");p.write_text(h,encoding='utf-8')
print({k:q[k] for k in ['reviewed_raw_samples','reviewed_boundary_samples','partial_reviewed_raw_samples']})
