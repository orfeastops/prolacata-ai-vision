from pathlib import Path
import json,hashlib
from datetime import datetime,timezone
b=Path('D:/Codex/tank-day28/heldout_counting');r=b/'day28_runs';now=datetime.now(timezone.utc).isoformat()
def read(p):return json.loads(p.read_text())
def save(p,q):p.write_text(json.dumps(q,indent=2))
clocks={105:'12:02:44 / 12:02:56',106:'12:03:25 / 12:04:05',107:'12:05:38 / 12:11:53',108:'12:12:18 / 12:12:34',109:'12:13:10 / 12:16:55',110:'12:17:29 / 12:18:02',111:'12:18:22 / 12:19:13',112:'12:19:27 / 12:19:41',113:'12:20:10 / 12:19:58 (repeated first frame)',114:'12:20:51 / 12:24:43',115:'12:25:13 / 12:28:23',116:'12:28:40 / 12:28:32 (repeated first frame)',117:'12:29:03 / 12:29:16',118:'12:29:34 / 12:29:49',119:'12:30:20 / 12:31:13',120:'12:31:35 / 12:55:03'}
bn=0
for i in range(105,121):
 p=r/f'boundary_{i-1}_{i}'/'evidence.json';q=read(p);n=len(q['samples']);bn+=n
 q.update(visual_review_pending=False,reviewed_at=now,visually_reviewed_samples=n,review_notes='Sampled previous tail / next first visible clocks: '+clocks[i]+'. People walking or stationary room, no sampled tank departure. Gaps and first-frame clock jumps retained; no constant offset or exhaustive coverage asserted.',aggregation_allowed=False)
 if i==109:q['supplemental_previous_tail_evidence']='../clip_108/raw_review_2s_16_40/sheet_00.jpg';q['supplemental_previous_tail_samples_reviewed']=5
 save(p,q)
for i in range(105,121):
 p=r/f'clip_{i:03}'/'review_queue.json';q=read(p);q['review_status']='sampled_visual_review_complete';q['review_notes']=q['review_notes'].replace('Boundaries pending.','Adjacent boundary samples reviewed; recording gaps retained.');q['reviewed_at']=now
 if i==108:q['reviewed_dense_samples']=5;q['evidence'].append('raw_review_2s_16_40/sheet_00.jpg')
 save(p,q)
partial=0
for i in range(121,141):
 d=r/f'clip_{i:03}';q=read(d/'review_queue.json');assert not q['automatic_proposals'];n=len(read(d/'raw_review_10s'/'samples.json'));partial+=n
 with (d/'source.mp4').open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
 assert sha==read(d/'source.json')['sha256']
 save(d/'source_hash_review.json',dict(checked_at=now,sha256=sha,matches_recorded=True,exact_duplicates_in_recorded_sources=[p.parent.name for p in r.glob('clip_*/source.json') if p.parent!=d and read(p).get('sha256')==sha]))
 q.update(review_status='sampled_raw_review_complete_boundary_pending',reviewed_at=now,reviewed_raw_samples=n,reviewed_dense_samples=0,sampling_s=10,manual_reference_exhaustive=False,confirmed_loaded_count=0,manual_observed_loaded_departures=0,aggregation_allowed=False,evidence=[str(x.relative_to(d)).replace('\\','/') for x in sorted((d/'raw_review_10s').glob('sheet_*.jpg'))],review_notes='All raw contact-sheet samples visually inspected. People walking, door opening/closing, hose/floor cleaning or stationary room; no sampled tank departure. Boundaries pending. Sampling not exhaustive.')
 save(d/'review_queue.json',q)
p=r/'manual_review_progress.json';q=read(p);q.update(reviewed_clips=[f'clip_{i:03}' for i in list(range(62))+list(range(63,121))],reviewed_raw_samples=1658,reviewed_dense_samples=936,reviewed_boundary_samples=585+bn,partially_reviewed_clips=[f'clip_{i:03}' for i in range(121,141)],partial_reviewed_raw_samples=partial,updated_at=now,note='120 clips sampled through120 excluding062;121-140 raw samples visually reviewed, boundaries pending. No new sampled departures.22 block-loaded and1other-material unchanged; fullclip separately3. Next raw141. Daily sum withheld.');save(p,q)
p=b/'review.html';h=p.read_text(encoding='utf-8');h=h.replace('104 αποσπάσματα: 1609 αραιά δείγματα και 931 πυκνότερα δείγματα','120 αποσπάσματα: 1658 αραιά δείγματα και 936 πυκνότερα δείγματα');h=h.replace('</body>',f'<p>Latest review {now}: 120 clips sampled through120 (062 separate);1658 coarse,936 dense,{585+bn} boundary samples. Clips121-140: {partial} additional coarse samples actually inspected, boundaries pending. No additional observed tank departure; people and cleaning activity. Gaps retained. Daily aggregation remains pending.</p></body>');p.write_text(h,encoding='utf-8')
print(dict(reviewed_clips=120,boundary=585+bn,partial_raw=partial))
