from pathlib import Path
import json
from PIL import Image,ImageDraw
b=Path('D:/Codex/tank-day28/heldout_counting');r=b/'day28_runs';q=json.loads((r/'final_reconciliation_todo.json').read_text())
for i in q['earlier_filename_overlap_pairs_requiring_evidence_consolidation']:
 o=r/f'consolidated_boundary_{i-1}_{i}';o.mkdir(exist_ok=True);rows=[]
 for j in [i-1,i]:
  if j==62:d=b/'fullclip_raw_review'
  else:
   d=r/f'clip_{j:03}'/'raw_review_10s'
   if not d.exists():d=r/f'clip_{j:03}'/'raw_review'
  samples=json.loads((d/'samples.json').read_text());sel=samples[-3:] if j==i-1 else samples[:3]
  for s in sel:rows.append(dict(clip=j,pts_s=s['pts_s'],file=str(d/s['file'])))
 sh=Image.new('RGB',(1920,780))
 for k,s in enumerate(rows):
  im=Image.open(s['file']);tile=Image.new('RGB',(640,390));tile.paste(im.resize((640,360)),(0,30));ImageDraw.Draw(tile).text((5,5),f"clip{s['clip']} PTS{s['pts_s']:.3f}",fill='white');sh.paste(tile,((k%3)*640,(k//3)*390))
 sh.save(o/'sheet.jpg');(o/'evidence.json').write_text(json.dumps(dict(samples=rows,visual_review_pending=True,uses_previously_reviewed_raw_samples=True),indent=2))
print('prepared',len(q['earlier_filename_overlap_pairs_requiring_evidence_consolidation']))
