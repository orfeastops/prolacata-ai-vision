"""Aggregate reviewed hand actions; this is not an automatic video recognizer.

Usage: python count_events.py feta_pilot_annotations.json --output report.json
"""
import argparse, json
from collections import defaultdict

def aggregate(data):
    if data.get('schema_version') != 1:
        raise ValueError('Unsupported schema')
    duration = data['source']['segment_duration_seconds']
    seen = set()
    intervals = defaultdict(list)
    tanks = {}
    for event in data['events']:
        eid = event['event_id']
        if eid in seen:
            raise ValueError(f'Duplicate event: {eid}')
        seen.add(eid)
        start, end = event['start_seconds'], event['end_seconds']
        if not 0 <= start < end <= duration:
            raise ValueError(f'Invalid interval: {eid}')
        worker, hand = event['worker'], event['hand']
        if worker not in ('A', 'B') or hand not in ('L', 'R', 'U'):
            raise ValueError(f'Invalid worker/hand: {eid}')
        for old_hand, old_start, old_end in intervals[worker]:
            if (hand == old_hand or hand == 'U' or old_hand == 'U') and start < old_end and end > old_start:
                raise ValueError(f'Overlapping hand actions: {eid}')
        intervals[worker].append((hand, start, end))
        destination, blocks, status = event['destination'], event['blocks'], event['status']
        if status not in ('confirmed', 'needs_review'):
            raise ValueError(f'Invalid status: {eid}')
        if destination == 'production':
            if type(blocks) is not int or not 1 <= blocks <= 4:
                raise ValueError(f'Invalid block count: {eid}')
        elif destination in ('crumb', 'return', 'separator'):
            if blocks != 0:
                raise ValueError(f'Non-production event must have zero blocks: {eid}')
        elif destination == 'unknown':
            if blocks is not None or status != 'needs_review':
                raise ValueError(f'Unknown action must remain unresolved: {eid}')
        else:
            raise ValueError(f'Invalid destination: {eid}')
        tank_id = event['tank_id']
        if not isinstance(tank_id, str) or not tank_id.strip():
            raise ValueError(f'Missing tank ID: {eid}')
        tank = tanks.setdefault(tank_id, dict(confirmed_blocks=0, unresolved_actions=0, crumb_disposals=0, confirmed_production_actions=0))
        if status != 'confirmed':
            tank['unresolved_actions'] += 1
        elif destination == 'production':
            tank['confirmed_blocks'] += blocks
            tank['confirmed_production_actions'] += 1
        elif destination == 'crumb':
            tank['crumb_disposals'] += 1
    return dict(source=data['source'], coverage='partial_manual_annotation', tanks=tanks,
                pending_actions=len(data.get('pending_actions', [])),
                full_tank_totals_available=False,
                note='Counts cover reviewed actions only. Crumb disposals are not crumb tank counts. No default of 228 blocks is applied.')

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('annotations')
    p.add_argument('--output', required=True)
    args = p.parse_args()
    with open(args.annotations, encoding='utf-8') as f:
        report = aggregate(json.load(f))
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)

if __name__ == '__main__':
    main()
