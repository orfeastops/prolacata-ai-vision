"""Train a first, limited hand detector on facility crops, not a production counter."""
import os,pathlib,json,time
ROOT=pathlib.Path(__file__).resolve().parent
os.environ['YOLO_CONFIG_DIR']=str(ROOT/'runtime_config')
os.environ['YOLO_AUTOINSTALL']='false'
os.environ['MPLBACKEND']='Agg'

def main():
    import torch,ultralytics
    from ultralytics import YOLO,settings
    torch.set_num_threads(4)
    settings.update({k:False for k in ('sync','wandb','mlflow','clearml','comet','neptune','tensorboard') if k in settings})
    hardware=dict(torch=torch.__version__,ultralytics=ultralytics.__version__,cuda_available=torch.cuda.is_available(),logical_cpus=os.cpu_count(),threads=4)
    (ROOT/'hardware.json').write_text(json.dumps(hardware,indent=2))
    os.chdir(ROOT)
    model=YOLO('yolo26n.pt')
    started=time.time()
    def progress(trainer):
        payload=dict(epoch=trainer.epoch+1,epochs=trainer.epochs,elapsed_seconds=round(time.time()-started),metrics={k:float(v) for k,v in trainer.metrics.items()})
        (ROOT/'training_progress.json').write_text(json.dumps(payload,indent=2))
    model.add_callback('on_fit_epoch_end',progress)
    model.train(data=str(ROOT/'dataset.yaml'),epochs=40,imgsz=640,batch=4,device='cpu',workers=0,
                project=str(ROOT/'runs'),name='hands_v1',exist_ok=True,freeze=11,
                optimizer='AdamW',lr0=0.001,patience=15,seed=42,deterministic=True,
                mosaic=0.15,close_mosaic=8,mixup=0.0,fliplr=0.5,flipud=0.0,
                degrees=5.0,translate=0.08,scale=0.2,cache=False,plots=True)
    best=YOLO(str(ROOT/'runs/hands_v1/weights/best.pt'))
    metrics=best.val(data=str(ROOT/'dataset.yaml'),imgsz=640,batch=4,device='cpu',workers=0,
                     project=str(ROOT/'runs'),name='hands_v1_validation',exist_ok=True,plots=True)
    summary=dict(hardware=hardware,metrics=metrics.results_dict,training_images=12,validation_images=12,
                 training_hand_boxes=38,validation_hand_boxes=19,
                 split='Train 2026-10-01; validation 2026-10-21',
                 scope='gloved_hand detection only in a fixed 640x360 crop of Camera 11',
                 labels='Assistant visual annotations, not expert-reviewed',
                 production_ready=False,block_counting_trained=False,tank_tracking_trained=False)
    (ROOT/'training_summary.json').write_text(json.dumps(summary,indent=2))
    best.predict(source=str(ROOT/'dataset/images/val'),conf=0.25,imgsz=640,device='cpu',save=True,
                 save_txt=True,save_conf=True,project=str(ROOT/'runs'),name='hands_v1_predictions',exist_ok=True)
    print('TRAINING_AND_VALIDATION_COMPLETED',flush=True)

if __name__=='__main__':main()
