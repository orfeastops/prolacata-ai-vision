"""Compare validation performance and save a clearly scoped trained checkpoint."""
import pathlib,json,shutil,os
ROOT=pathlib.Path(__file__).resolve().parent
os.environ['YOLO_CONFIG_DIR']=str(ROOT/'runtime_config')
os.environ['YOLO_AUTOINSTALL']='false'

def iou(a,b):
    intersection=max(0,min(a[2],b[2])-max(a[0],b[0]))*max(0,min(a[3],b[3])-max(a[1],b[1]))
    union=(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-intersection
    return intersection/union if union else 0

def main():
    import torch
    from ultralytics import YOLO
    from PIL import Image,ImageDraw
    torch.set_num_threads(4)
    summaries={version:json.loads((ROOT/f'training_summary{suffix}.json').read_text()) for version,suffix in [('v1',''),('v2','_v2')]}
    chosen=max(summaries,key=lambda v:summaries[v]['metrics']['metrics/mAP50-95(B)'])
    weights=ROOT/f'runs/hands_{chosen}/weights/best.pt'
    shutil.copyfile(weights,ROOT/'hands_detector.pt')
    data=json.loads((ROOT/'manual_annotations_v2.json').read_text())
    val=[r for r in data if r['split']=='val']
    model=YOLO(str(weights));stats={str(c):dict(tp=0,fp=0,fn=0) for c in (.05,.1,.25,.5)};per_image=[]
    previews=[]
    for r in val:
        path=ROOT/'dataset_v2/images/val'/r['image']
        result=model.predict(str(path),conf=.05,imgsz=640,device='cpu',verbose=False)[0]
        predictions=[dict(box=[float(x) for x in b.xyxy[0]],confidence=float(b.conf[0])) for b in result.boxes]
        for threshold in (.05,.1,.25,.5):
            remaining=set(range(len(r['boxes_xyxy'])));tp=fp=0
            for pred in sorted((p for p in predictions if p['confidence']>=threshold),key=lambda p:-p['confidence']):
                if remaining:
                    match=max(remaining,key=lambda i:iou(pred['box'],r['boxes_xyxy'][i]))
                    if iou(pred['box'],r['boxes_xyxy'][match])>=.5:tp+=1;remaining.remove(match);continue
                fp+=1
            s=stats[str(threshold)];s['tp']+=tp;s['fp']+=fp;s['fn']+=len(remaining)
        per_image.append(dict(image=r['image'],ground_truth=r['boxes_xyxy'],predictions=predictions))
        im=Image.open(path).convert('RGB');d=ImageDraw.Draw(im)
        for b in r['boxes_xyxy']:d.rectangle(b,outline='yellow',width=1)
        for p in predictions:
            if p['confidence']>=.1:
                d.rectangle(p['box'],outline='#00ff88',width=2)
                d.text((p['box'][0],max(0,p['box'][1]-12)),f"{p['confidence']:.2f}",fill='#00ff88',stroke_width=1,stroke_fill='black')
        tile=Image.new('RGB',(640,400),'white');tile.paste(im,(0,30));ImageDraw.Draw(tile).text((5,5),r['image']+' | yellow: label, green: prediction >=0.10',fill='black');previews.append(tile)
    for s in stats.values():
        s['precision']=s['tp']/(s['tp']+s['fp']) if s['tp']+s['fp'] else 0
        s['recall']=s['tp']/(s['tp']+s['fn']) if s['tp']+s['fn'] else 0
    report=dict(selected=chosen,selection_metric='validation mAP50-95',models=summaries,
                fixed_threshold_validation_at_iou_0_5=stats,
                warning='Only 12 validation images and 19 hand boxes; no independent test set, no expert review. This is not block-count accuracy.',
                trained_classes=['gloved_hand'],crop_xyxy=[800,720,1440,1080],production_ready=False)
    (ROOT/'model_report.json').write_text(json.dumps(report,indent=2))
    (ROOT/'validation_detections.json').write_text(json.dumps(per_image,indent=2))
    for page in range(3):
        sheet=Image.new('RGB',(1280,800),'white')
        for j,tile in enumerate(previews[page*4:(page+1)*4]):sheet.paste(tile,((j%2)*640,(j//2)*400))
        sheet.save(ROOT/f'validation_comparison_{page+1}.jpg')
    print(json.dumps(dict(selected=chosen,thresholds=stats),indent=2))

if __name__=='__main__':main()
