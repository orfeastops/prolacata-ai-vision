"""Run the trained hand detector on camera 11 footage; outputs detections, not block counts.

python predict_hands.py --video INPUT.mp4 --weights hands_detector.pt --output predictions
Uses the fixed facility-camera crop x=800:1440, y=720:1080.
"""
import os,pathlib,argparse,json,subprocess
ROOT=pathlib.Path(__file__).resolve().parent
os.environ['YOLO_CONFIG_DIR']=str(ROOT/'runtime_config')
os.environ['YOLO_AUTOINSTALL']='false'

def main():
    import cv2,torch
    from ultralytics import YOLO
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--video',required=True)
    p.add_argument('--weights',default=str(ROOT/'hands_detector.pt'))
    p.add_argument('--output',required=True)
    p.add_argument('--seconds',type=float,default=30)
    p.add_argument('--confidence',type=float,default=0.25)
    args=p.parse_args()
    output=pathlib.Path(args.output);output.mkdir(parents=True,exist_ok=True)
    torch.set_num_threads(4)
    model=YOLO(args.weights)
    cap=cv2.VideoCapture(args.video)
    if not cap.isOpened():raise RuntimeError('Cannot decode input video')
    # Decode sequentially. These DVR exports may corrupt when seeking directly.
    writer=cv2.VideoWriter(str(output/'hands_preview.avi'),cv2.VideoWriter_fourcc(*'MJPG'),10,(640,360))
    if not writer.isOpened():raise RuntimeError('Cannot create preview')
    i=0;last_sample=-1;records=[]
    while True:
        ok,frame=cap.read()
        if not ok:break
        t=cap.get(cv2.CAP_PROP_POS_MSEC)/1000
        if t>args.seconds:break
        tick=int(t*10)
        if tick<=last_sample:continue
        last_sample=tick
        if frame.shape[0]<1080 or frame.shape[1]<1440:raise ValueError('Expected original 1920x1080 camera view')
        crop=frame[720:1080,800:1440]
        result=model.predict(crop,conf=args.confidence,imgsz=640,device='cpu',verbose=False)[0]
        detections=[dict(xyxy_crop=[round(float(x),2) for x in b.xyxy[0]],confidence=round(float(b.conf[0]),4),class_name='gloved_hand') for b in result.boxes]
        records.append(dict(relative_seconds=round(t,3),detections=detections))
        rendered=result.plot(line_width=1,font_size=9)
        cv2.putText(rendered,f'Hand detection only | +{t:.2f}s',(8,20),cv2.FONT_HERSHEY_SIMPLEX,.5,(0,255,255),1)
        writer.write(rendered)
        if i in (0,50,100,150):cv2.imwrite(str(output/f'prediction_{i:04d}.jpg'),rendered)
        i+=1
    cap.release();writer.release()
    (output/'detections.json').write_text(json.dumps(dict(source=str(pathlib.Path(args.video).resolve()),weights=str(pathlib.Path(args.weights).resolve()),crop_xyxy=[800,720,1440,1080],confidence=args.confidence,counts_available=False,frames=records),indent=2))
    print(f'Saved {i} annotated frames; no production/block counts inferred.')

if __name__=='__main__':main()
