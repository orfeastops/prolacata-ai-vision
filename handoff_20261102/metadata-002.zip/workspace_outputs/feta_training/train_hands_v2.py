"""Second local training iteration with additional times and negative images."""
import os,pathlib,json,time
ROOT=pathlib.Path(__file__).resolve().parent
os.environ['YOLO_CONFIG_DIR']=str(ROOT/'runtime_config')
os.environ['YOLO_AUTOINSTALL']='false'
os.environ['MPLBACKEND']='Agg'

def main():
    import torch
    from ultralytics import YOLO
    torch.set_num_threads(4)
    model=YOLO(str(ROOT/'runs/hands_v1/weights/best.pt'))
    started=time.time()
    def progress(trainer):
        (ROOT/'training_progress_v2.json').write_text(json.dumps(dict(epoch=trainer.epoch+1,epochs=trainer.epochs,elapsed_seconds=round(time.time()-started),metrics={k:float(v) for k,v in trainer.metrics.items()}),indent=2))
    model.add_callback('on_fit_epoch_end',progress)
    model.train(data=str(ROOT/'dataset_v2.yaml'),epochs=30,imgsz=640,batch=4,device='cpu',workers=0,
                project=str(ROOT/'runs'),name='hands_v2',exist_ok=True,freeze=11,
                optimizer='AdamW',lr0=0.0007,patience=12,seed=43,deterministic=True,
                mosaic=0.15,close_mosaic=8,mixup=0.0,fliplr=0.5,flipud=0.0,
                degrees=5.0,translate=0.08,scale=0.2,cache=False,plots=True)
    best=YOLO(str(ROOT/'runs/hands_v2/weights/best.pt'))
    metrics=best.val(data=str(ROOT/'dataset_v2.yaml'),imgsz=640,batch=4,device='cpu',workers=0,
                     project=str(ROOT/'runs'),name='hands_v2_validation',exist_ok=True,plots=True)
    summary=dict(metrics=metrics.results_dict,training_images=22,validation_images=12,
                 training_hand_boxes=52,validation_hand_boxes=19,
                 split='Train 2026-10-01; validation 2026-10-21. No independent test set yet.',
                 scope='gloved_hand detection only in crop x=800..1440, y=720..1080 of Camera 11',
                 labels='Assistant manual visual annotations; not expert-reviewed',
                 production_ready=False,block_counting_trained=False,tank_tracking_trained=False)
    (ROOT/'training_summary_v2.json').write_text(json.dumps(summary,indent=2))
    best.predict(source=str(ROOT/'dataset_v2/images/val'),conf=0.25,imgsz=640,device='cpu',save=True,
                 save_txt=True,save_conf=True,project=str(ROOT/'runs'),name='hands_v2_predictions',exist_ok=True)
    print('SECOND_TRAINING_AND_VALIDATION_COMPLETED',flush=True)

if __name__=='__main__':main()
