"""Persistent bookkeeping for future continuous camera inference.

This module does not connect cameras or infer objects. An upstream tracker must
supply stable physical-release IDs and validated quantities/destinations. Video
buffers and process restarts never start a new tank or clear its count.
"""
import datetime
import json
import sqlite3


class LiveState:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.executescript('''
          CREATE TABLE IF NOT EXISTS tanks(
            tank_id TEXT PRIMARY KEY, started_at TEXT NOT NULL,
            initially_empty_confirmed INTEGER NOT NULL,
            coverage_certified INTEGER NOT NULL DEFAULT 0,
            filling_active INTEGER NOT NULL DEFAULT 1);
          CREATE TABLE IF NOT EXISTS placements(
            event_id TEXT PRIMARY KEY, tank_id TEXT NOT NULL REFERENCES tanks(tank_id),
            quantity INTEGER, object_kind TEXT NOT NULL, destination TEXT NOT NULL,
            captured_at TEXT NOT NULL, time_basis TEXT NOT NULL, status TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS transitions(
            event_id TEXT PRIMARY KEY, tank_id TEXT NOT NULL REFERENCES tanks(tank_id),
            kind TEXT NOT NULL, captured_at TEXT NOT NULL,
            time_basis TEXT NOT NULL, validated INTEGER NOT NULL);
          CREATE TABLE IF NOT EXISTS gaps(
            gap_id TEXT NOT NULL, tank_id TEXT NOT NULL REFERENCES tanks(tank_id),
            started_at TEXT NOT NULL, ended_at TEXT NOT NULL,
            PRIMARY KEY(gap_id,tank_id));
        ''')

    @staticmethod
    def _time(value):
        dt = datetime.datetime.fromisoformat(value)
        if dt.tzinfo is None:
            raise ValueError('Live capture timestamps require an explicit UTC offset')
        return dt.astimezone(datetime.timezone.utc).isoformat()

    def close(self):
        self.db.close()

    def start_tank(self, tank_id, captured_at, initially_empty_confirmed=False):
        if not tank_id:
            raise ValueError('A persistent tank identity is required')
        with self.db:
            self.db.execute('INSERT OR IGNORE INTO tanks(tank_id,started_at,initially_empty_confirmed) VALUES(?,?,?)',
                            (tank_id,self._time(captured_at),int(initially_empty_confirmed)))

    def placement(self, event_id, tank_id, quantity, object_kind, destination,
                  captured_at, validated=False, time_basis='camera_clock_unverified'):
        if not event_id:
            raise ValueError('A stable physical-release event identity is required')
        if quantity is not None and (type(quantity) is not int or quantity < 0):
            raise ValueError('Quantity must be a non-negative integer or unknown')
        excluded = object_kind in {'crumbs','separator'} or destination in {'crumb_tank','separator_rack','conveyor_return'}
        status = 'excluded' if validated and excluded else 'pending'
        if validated and object_kind == 'whole_cheese_block' and destination == 'filling_tank' and quantity is not None:
            status = 'accepted'
        values=(event_id,tank_id,quantity,object_kind,destination,self._time(captured_at),time_basis,status)
        with self.db:
            previous=self.db.execute('SELECT * FROM placements WHERE event_id=?',(event_id,)).fetchone()
            if previous:
                if previous == values:
                    return False
                if previous[1] != tank_id or previous[-1] in {'accepted','excluded'}:
                    raise ValueError('Conflicting physical event; explicit review required')
                self.db.execute('UPDATE placements SET quantity=?,object_kind=?,destination=?,captured_at=?,time_basis=?,status=? WHERE event_id=?',
                                (quantity,object_kind,destination,values[5],time_basis,status,event_id))
            else:
                self.db.execute('INSERT INTO placements VALUES(?,?,?,?,?,?,?,?)',values)
        return status == 'accepted'

    def transition(self, event_id, tank_id, kind, captured_at, validated=False,
                   time_basis='camera_clock_unverified'):
        if not event_id or kind not in {'departed_camera11','arrived_camera15','stored_camera15'}:
            raise ValueError('Invalid tank transition')
        values=(event_id,tank_id,kind,self._time(captured_at),time_basis,int(validated))
        with self.db:
            previous=self.db.execute('SELECT * FROM transitions WHERE event_id=?',(event_id,)).fetchone()
            if previous:
                if previous == values:return False
                if previous[1:5] != values[1:5] or previous[-1]:
                    raise ValueError('Conflicting tank association; explicit review required')
                self.db.execute('UPDATE transitions SET validated=? WHERE event_id=?',(int(validated),event_id))
            else:
                self.db.execute('INSERT INTO transitions VALUES(?,?,?,?,?,?)',values)
            if validated and kind == 'departed_camera11':
                self.db.execute('UPDATE tanks SET filling_active=0 WHERE tank_id=?',(tank_id,))
        return bool(validated)

    def record_gap(self, gap_id, started_at, ended_at):
        start,end=self._time(started_at),self._time(ended_at)
        if start>end:raise ValueError('Gap end precedes start')
        with self.db:
            for (tank_id,) in self.db.execute('SELECT tank_id FROM tanks WHERE filling_active=1').fetchall():
                self.db.execute('INSERT OR IGNORE INTO gaps VALUES(?,?,?,?)',(gap_id,tank_id,start,end))
                self.db.execute('UPDATE tanks SET coverage_certified=0 WHERE tank_id=?',(tank_id,))

    def certify_coverage(self, tank_id):
        """Upstream review must establish complete filling-interval coverage."""
        with self.db:
            if self.db.execute('SELECT 1 FROM gaps WHERE tank_id=?',(tank_id,)).fetchone():
                raise ValueError('Recorded frame loss needs resolution before certifying a total')
            self.db.execute('UPDATE tanks SET coverage_certified=1 WHERE tank_id=?',(tank_id,))

    def report(self, tank_id):
        tank=self.db.execute('SELECT * FROM tanks WHERE tank_id=?',(tank_id,)).fetchone()
        if tank is None:raise KeyError(tank_id)
        confirmed=self.db.execute("SELECT COALESCE(SUM(quantity),0) FROM placements WHERE tank_id=? AND status='accepted'",(tank_id,)).fetchone()[0]
        pending=self.db.execute("SELECT event_id FROM placements WHERE tank_id=? AND status='pending' ORDER BY event_id",(tank_id,)).fetchall()
        transitions=self.db.execute('SELECT kind,captured_at,time_basis,validated FROM transitions WHERE tank_id=? ORDER BY captured_at',(tank_id,)).fetchall()
        times={kind:{'captured_at':stamp,'time_basis':basis} for kind,stamp,basis,valid in transitions if valid}
        gaps=self.db.execute('SELECT gap_id,started_at,ended_at FROM gaps WHERE tank_id=?',(tank_id,)).fetchall()
        complete=bool(tank[2] and tank[3] and not tank[4] and not pending and not gaps)
        return {'tank_id':tank_id,'confirmed_blocks':confirmed,'exact_block_total':confirmed if complete else None,
                'count_complete':complete,'unresolved_event_ids':[x[0] for x in pending],
                'validated_transition_times':times,'unverified_transition_count':sum(not x[-1] for x in transitions),
                'coverage_gaps':gaps,'filling_active':bool(tank[4]),
                'fixed_tank_total':None,'fixed_blocks_per_gesture':None}
