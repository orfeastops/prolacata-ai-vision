"""Evidence bookkeeping for facility counts; this module is not an image model.

An upstream tracker must supply persistent worker/hand, tray-cycle and tank IDs.
Tray height changes corroborate pickups. Only observed releases into the filling
tank add production; removing a separator or dropping crumbs never does.
"""
from dataclasses import dataclass, field, replace


@dataclass(frozen=True)
class HandTransfer:
    event_id: str
    worker_track: str
    hand_track: str
    tray_cycle_id: str
    tank_id: str
    picked_quantity: int | None
    pickup_object: str
    release_object: str
    destination: str
    pickup_observed: bool
    release_observed: bool
    release_relative_s: float | None
    quantity_basis: str = "unknown"
    pickup_episode_id: str = ""


@dataclass
class ProductionLedger:
    accepted: dict = field(default_factory=dict)
    pending: dict = field(default_factory=dict)
    excluded: dict = field(default_factory=dict)
    conflicts: list = field(default_factory=list)
    finalized_transfer_keys: dict = field(default_factory=dict)

    def ingest(self, event: HandTransfer):
        """Repeated observations of an event cannot increase a tank count."""
        key = (event.worker_track, event.hand_track, event.tray_cycle_id, event.pickup_episode_id) if event.pickup_episode_id else None
        previous_id = self.finalized_transfer_keys.get(key, event.event_id) if key else event.event_id
        previous = self.accepted.get(previous_id) or self.excluded.get(previous_id)
        if previous is not None:
            if previous != replace(event, event_id=previous.event_id):
                self.conflicts.append({"event_id": event.event_id, "reason": "changed finalized event; review required"})
            return
        if event.picked_quantity is not None and (type(event.picked_quantity) is not int or event.picked_quantity < 0):
            raise ValueError("Quantity must be a non-negative whole integer or unknown")
        if event.release_observed and (
            event.destination in {"crumb_tank", "separator_rack", "conveyor_return"}
            or event.release_object in {"crumbs", "separator"}
        ):
            self.excluded[event.event_id] = event
            if key:self.finalized_transfer_keys[key]=event.event_id
            self.pending.pop(event.event_id, None)
            return
        verified_quantity = event.quantity_basis in {"user_reviewed", "visually_reviewed", "validated_model"}
        if (
            event.pickup_observed and event.release_observed
            and event.destination == "filling_tank"
            and event.pickup_object == event.release_object == "whole_cheese_block"
            and verified_quantity and event.picked_quantity is not None
            and event.release_relative_s is not None
            and event.tank_id and event.tray_cycle_id
        ):
            self.accepted[event.event_id] = event
            if key:self.finalized_transfer_keys[key]=event.event_id
            self.pending.pop(event.event_id, None)
        else:
            self.pending[event.event_id] = event

    def corroborate_tray(self, tray_cycle_id: str, observed_decrease: int | None, capacity=10, pickup_episode_ids=None):
        if observed_decrease is not None and not 0 <= observed_decrease <= capacity:
            raise ValueError("Tray decrease outside capacity")
        events = {**self.accepted, **self.pending, **self.excluded}.values()
        picked = [e for e in events if e.tray_cycle_id == tray_cycle_id and e.pickup_observed
                  and e.pickup_object == "whole_cheese_block"
                  and (pickup_episode_ids is None or e.pickup_episode_id in pickup_episode_ids)]
        quantities_known = all(e.picked_quantity is not None for e in picked)
        hand_quantity = sum(e.picked_quantity for e in picked) if quantities_known else None
        return {
            "tray_cycle_id": tray_cycle_id, "capacity": capacity,
            "pickup_episode_ids": pickup_episode_ids,
            "observed_decrease": observed_decrease, "hand_pickup_quantity": hand_quantity,
            "consistent": None if observed_decrease is None or hand_quantity is None else observed_decrease == hand_quantity,
            "production_added_by_tray_check": 0,
            "note": "Compare only the same tracked pickup episode; unseen or occluded slots remain unknown.",
        }

    def report(self):
        tanks = {}
        for event in self.accepted.values():
            tanks[event.tank_id] = tanks.get(event.tank_id, 0) + event.picked_quantity
        return {"confirmed_blocks_by_tank": tanks, "accepted_events": len(self.accepted),
                "pending_event_ids": sorted(self.pending), "excluded_events": len(self.excluded),
                "conflicts": self.conflicts,
                "scope": "Only supplied reviewed evidence, not a complete video/day production total"}
